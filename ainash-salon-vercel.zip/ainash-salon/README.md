# Айнаш — сайт для Vercel

В папке: index.html, robots.txt, sitemap.xml, vercel.json, favicon.svg, og-image.png, 404.html.

## Как опубликовать
1. Установите Node.js и откройте терминал в этой папке.
2. `npx vercel --prod` — Vercel попросит войти и спросит название проекта (например, ainash-salon), потом покажет адрес вида https://ainash-salon.vercel.app.
3. Подставьте этот адрес (или свой домен) в файлы для поиска: `node set-domain.js https://ainash-salon.vercel.app`, затем снова `npx vercel --prod`.
4. Google Search Console: добавьте сайт и отправьте карту сайта `https://ВАШ-АДРЕС/sitemap.xml`. Индексация занимает от нескольких дней.

## Заметки
- В поиск попадает только production-деплой (`--prod`); превью-деплои Vercel закрывает от индексации.
- Вместо CLI можно загрузить папку в GitHub и импортировать репозиторий в Vercel (Framework Preset: Other).
- Рейтинги 4.7 и 4.5 на странице взяты из 2ГИС. В разметку для Google они намеренно не добавлены: правила Google не разрешают использовать чужие рейтинги.
- Пока в файлах стоит YOUR-DOMAIN, canonical и sitemap указывают на несуществующий адрес. Не забудьте шаг 3.
