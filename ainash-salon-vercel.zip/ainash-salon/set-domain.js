// Подставляет адрес сайта в index.html, sitemap.xml и robots.txt.
// Использование: node set-domain.js https://ainash-salon.vercel.app
const fs = require("fs");
const d = (process.argv[2] || "").replace(/\/+$/, "");
if (!/^https?:\/\/[^\s/]+$/.test(d)) { console.log("Укажите адрес: node set-domain.js https://ваш-сайт.vercel.app"); process.exit(1); }
for (const f of ["index.html", "sitemap.xml", "robots.txt"]) {
  fs.writeFileSync(f, fs.readFileSync(f, "utf8").split("https://YOUR-DOMAIN").join(d));
}
console.log("Готово:", d);
